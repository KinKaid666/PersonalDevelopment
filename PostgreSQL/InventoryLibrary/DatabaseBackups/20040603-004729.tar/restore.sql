create temporary table pgdump_restore_path(p text);
--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
-- Edit the following to match the path where the
-- tar archive has been extracted.
--
insert into pgdump_restore_path values('/tmp');

--
-- PostgreSQL database dump
--

SET client_encoding = 'SQL_ASCII';
SET check_function_bodies = false;

SET SESSION AUTHORIZATION 'postgres';

SET SESSION AUTHORIZATION 'etf2954';

SET search_path = public, pg_catalog;

ALTER TABLE ONLY public.inventory_items DROP CONSTRAINT "$2";
ALTER TABLE ONLY public.inventory_items DROP CONSTRAINT "$1";
ALTER TABLE ONLY public.inventory_types DROP CONSTRAINT inventory_types_pkey;
ALTER TABLE ONLY public.inventory_owners DROP CONSTRAINT inventory_owners_pkey;
DROP INDEX public.inventory_items_title_index;
DROP INDEX public.inventory_items_id_index;
DROP INDEX public.inventory_owners_names_index;
DROP TABLE public.inventory_items;
DROP TABLE public.inventory_types;
DROP TABLE public.inventory_owners;
SET SESSION AUTHORIZATION 'postgres';

--
-- TOC entry 4 (OID 2200)
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
GRANT ALL ON SCHEMA public TO PUBLIC;


SET SESSION AUTHORIZATION 'etf2954';

--
-- TOC entry 5 (OID 17190)
-- Name: inventory_owners; Type: TABLE; Schema: public; Owner: etf2954
--

CREATE TABLE inventory_owners (
    inventory_owner_id serial NOT NULL,
    first_name character varying(15) NOT NULL,
    last_name character varying(30) NOT NULL,
    address1 character varying(50),
    address2 character varying(50),
    city character varying(20),
    state character(2),
    zip character varying(10),
    phone character varying(13),
    email character varying(30),
    creation_user character varying(30) DEFAULT "current_user"(),
    creation_date timestamp without time zone DEFAULT now()
);


--
-- TOC entry 6 (OID 17190)
-- Name: inventory_owners; Type: ACL; Schema: public; Owner: etf2954
--

REVOKE ALL ON TABLE inventory_owners FROM PUBLIC;
GRANT INSERT,SELECT,UPDATE,DELETE ON TABLE inventory_owners TO il_tester;


--
-- TOC entry 7 (OID 17197)
-- Name: inventory_types; Type: TABLE; Schema: public; Owner: etf2954
--

CREATE TABLE inventory_types (
    inventory_type_id serial NOT NULL,
    name character varying(20) NOT NULL,
    description character varying(80) NOT NULL,
    creation_user character varying(30) DEFAULT "current_user"(),
    creation_date timestamp without time zone DEFAULT now()
);


--
-- TOC entry 8 (OID 17197)
-- Name: inventory_types; Type: ACL; Schema: public; Owner: etf2954
--

REVOKE ALL ON TABLE inventory_types FROM PUBLIC;
GRANT INSERT,SELECT,UPDATE,DELETE ON TABLE inventory_types TO il_tester;


--
-- TOC entry 9 (OID 17204)
-- Name: inventory_items; Type: TABLE; Schema: public; Owner: etf2954
--

CREATE TABLE inventory_items (
    inventory_item_id serial NOT NULL,
    inventory_owner_id integer NOT NULL,
    title character varying(50) NOT NULL,
    author character varying(50),
    publisher character varying(50),
    quantity integer DEFAULT 1 NOT NULL,
    inventory_type_id integer NOT NULL,
    purchase_date timestamp without time zone DEFAULT ('now'::text)::date NOT NULL,
    purchase_price numeric(8,2) DEFAULT 0.00 NOT NULL,
    creation_user character varying(30) DEFAULT "current_user"(),
    creation_date timestamp without time zone DEFAULT now()
);


--
-- TOC entry 10 (OID 17204)
-- Name: inventory_items; Type: ACL; Schema: public; Owner: etf2954
--

REVOKE ALL ON TABLE inventory_items FROM PUBLIC;
GRANT INSERT,SELECT,UPDATE,DELETE ON TABLE inventory_items TO il_tester;


--
-- Data for TOC entry 19 (OID 17190)
-- Name: inventory_owners; Type: TABLE DATA; Schema: public; Owner: etf2954
-- File: 19.dat
--

--
-- Data for TOC entry 20 (OID 17197)
-- Name: inventory_types; Type: TABLE DATA; Schema: public; Owner: etf2954
-- File: 20.dat
--

--
-- Data for TOC entry 21 (OID 17204)
-- Name: inventory_items; Type: TABLE DATA; Schema: public; Owner: etf2954
-- File: 21.dat
--

--
-- TOC entry 14 (OID 17217)
-- Name: inventory_owners_names_index; Type: INDEX; Schema: public; Owner: etf2954
--

CREATE INDEX inventory_owners_names_index ON inventory_owners USING btree (first_name, last_name);


--
-- TOC entry 17 (OID 17218)
-- Name: inventory_items_id_index; Type: INDEX; Schema: public; Owner: etf2954
--

CREATE INDEX inventory_items_id_index ON inventory_items USING btree (inventory_item_id);


--
-- TOC entry 18 (OID 17219)
-- Name: inventory_items_title_index; Type: INDEX; Schema: public; Owner: etf2954
--

CREATE INDEX inventory_items_title_index ON inventory_items USING btree (title);


--
-- TOC entry 15 (OID 17220)
-- Name: inventory_owners_pkey; Type: CONSTRAINT; Schema: public; Owner: etf2954
--

ALTER TABLE ONLY inventory_owners
    ADD CONSTRAINT inventory_owners_pkey PRIMARY KEY (inventory_owner_id);


--
-- TOC entry 16 (OID 17222)
-- Name: inventory_types_pkey; Type: CONSTRAINT; Schema: public; Owner: etf2954
--

ALTER TABLE ONLY inventory_types
    ADD CONSTRAINT inventory_types_pkey PRIMARY KEY (inventory_type_id);


--
-- TOC entry 22 (OID 17224)
-- Name: $1; Type: FK CONSTRAINT; Schema: public; Owner: etf2954
--

ALTER TABLE ONLY inventory_items
    ADD CONSTRAINT "$1" FOREIGN KEY (inventory_owner_id) REFERENCES inventory_owners(inventory_owner_id);


--
-- TOC entry 23 (OID 17228)
-- Name: $2; Type: FK CONSTRAINT; Schema: public; Owner: etf2954
--

ALTER TABLE ONLY inventory_items
    ADD CONSTRAINT "$2" FOREIGN KEY (inventory_type_id) REFERENCES inventory_types(inventory_type_id);


--
-- TOC entry 11 (OID 17188)
-- Name: inventory_owners_inventory_owner_id_seq; Type: SEQUENCE SET; Schema: public; Owner: etf2954
--

SELECT pg_catalog.setval('inventory_owners_inventory_owner_id_seq', 5, true);


--
-- TOC entry 12 (OID 17195)
-- Name: inventory_types_inventory_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: etf2954
--

SELECT pg_catalog.setval('inventory_types_inventory_type_id_seq', 1, true);


--
-- TOC entry 13 (OID 17202)
-- Name: inventory_items_inventory_item_id_seq; Type: SEQUENCE SET; Schema: public; Owner: etf2954
--

SELECT pg_catalog.setval('inventory_items_inventory_item_id_seq', 1, false);


SET SESSION AUTHORIZATION 'postgres';

--
-- TOC entry 3 (OID 2200)
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'Standard public schema';


